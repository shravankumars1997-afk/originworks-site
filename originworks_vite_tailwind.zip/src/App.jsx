import React from 'react'
import logo from './assets/logo.png'

export default function App(){
    return (
        <div className="min-h-screen bg-white text-slate-900">
            <header className="bg-white py-6 shadow-sm">
                <div className="container mx-auto px-6 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <img src={logo} alt="Origin Works" className="h-10 w-10 object-contain" />
                        <span className="font-semibold text-lg">Origin Works</span>
                    </div>
                    <nav className="hidden md:flex gap-6 text-slate-600">
                        <a href="#services" className="hover:text-slate-900">Services</a>
                        <a href="#work" className="hover:text-slate-900">Work</a>
                        <a href="#contact" className="hover:text-slate-900">Contact</a>
                    </nav>
                </div>
            </header>
            <main className="container mx-auto px-6 py-20">
                <section className="grid md:grid-cols-2 gap-8 items-center">
                    <div>
                        <h1 className="text-4xl font-bold">Creativity. Execution. Growth.</h1>
                        <p className="mt-4 text-slate-600">Origin Works is a full-stack creative agency delivering Product Design, UI/UX, Branding, Photography, Videography, and Digital Marketing. We build solutions that scale.</p>
                        <div className="mt-6 flex gap-4">
                            <a href="#contact" className="px-5 py-3 bg-slate-900 text-white rounded-md">Get a Quote</a>
                            <a href="#work" className="px-5 py-3 border rounded-md">View Portfolio</a>
                        </div>
                    </div>
                    <div className="rounded-xl p-6 bg-gradient-to-br from-sky-50 to-emerald-50 border">
                        <img src={logo} alt="Origin Works" className="mx-auto h-48 w-48 object-contain" />
                    </div>
                </section>
                <section id="services" className="mt-16">
                    <h2 className="text-2xl font-semibold">Our Services</h2>
                    <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div className="p-6 border rounded-lg">
                            <h3 className="font-semibold">Product Design</h3>
                            <p className="text-sm text-slate-600 mt-2">End-to-end product design from research to prototype.</p>
                        </div>
                        <div className="p-6 border rounded-lg">
                            <h3 className="font-semibold">UI / UX Design</h3>
                            <p className="text-sm text-slate-600 mt-2">User-centered interfaces and experiences that convert.</p>
                        </div>
                        <div className="p-6 border rounded-lg">
                            <h3 className="font-semibold">Branding & Marketing</h3>
                            <p className="text-sm text-slate-600 mt-2">Brand systems, campaigns and growth marketing.</p>
                        </div>
                        <div className="p-6 border rounded-lg">
                            <h3 className="font-semibold">Photography</h3>
                            <p className="text-sm text-slate-600 mt-2">Product & lifestyle photography for marketing.</p>
                        </div>
                        <div className="p-6 border rounded-lg">
                            <h3 className="font-semibold">Videography</h3>
                            <p className="text-sm text-slate-600 mt-2">Promotional films and social content.</p>
                        </div>
                        <div className="p-6 border rounded-lg">
                            <h3 className="font-semibold">Interior Design</h3>
                            <p className="text-sm text-slate-600 mt-2">Residential and commercial interior design services.</p>
                        </div>
                    </div>
                </section>
                <section id="contact" className="mt-16">
                    <h2 className="text-2xl font-semibold">Contact</h2>
                    <p className="mt-2 text-sm text-slate-600">Email: hello@originworks.com | Phone: +91 90194 04928</p>
                </section>
            </main>
            <footer className="py-6 border-t mt-12">
                <div className="container mx-auto px-6 text-sm text-slate-500 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <img src={logo} alt="Origin Works" className="h-8 w-8 object-contain" />
                        <span>© {new Date().getFullYear()} Origin Works</span>
                    </div>
                    <div>Bengaluru • Serving clients worldwide</div>
                </div>
            </footer>
        </div>
    )
}
