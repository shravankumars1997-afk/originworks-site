# Origin Works - Vite + React + Tailwind Starter

This is a ready-to-run starter project for the Origin Works website.

## Setup

1. Install dependencies:

```bash
npm install
```

2. Run dev server:

```bash
npm run dev
```

3. Build for production:

```bash
npm run build
```

## Add your logo

Logo is included at `src/assets/logo.png`. Replace it with your final PNG if needed.

## Deploying

### Vercel
1. Create a Vercel account at https://vercel.com/
2. Import the project repository (or drag & drop the folder) and deploy. Vercel will auto-detect Vite.

### Netlify
1. Create a Netlify account at https://app.netlify.com/
2. Drag and drop the `dist/` folder (after `npm run build`) to deploy, or connect via Git provider and set build command `npm run build` and publish directory `dist`.

## Notes
- Tailwind is pre-configured. To customize, update `tailwind.config.cjs`.
- Replace placeholder content and portfolio images in `src`.
